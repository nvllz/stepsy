# Task: Plan the "Reports" screen for Stepsy (MotionMate)

You are planning a new feature for an existing, polished Android app. Your output will be handed to an implementing AI agent (OpenCode, working directly in the repo). Return **two deliverables**, described in section 6.

## 1. What Stepsy is

- Kotlin + Jetpack Compose (Material3) pedometer app. **Steps only** — there is no weight, food, sleep, or workout data.
- Deliberately small architecture: one main `MainActivity` hosting `HomeScreen`; secondary screens are lightweight `AppCompatActivity`s launched via intents (see `DailyGoalsActivity`, `AchievementsActivity`, `AndroidManifest.xml`), each doing `setContent { StepsyTheme { ... } }`.
- No DI, no Room, no ViewModel library. Data comes from:
  - a singleton raw-SQLite `Database` (`util/Database.kt`),
  - DataStore preferences (`util/AppPreferences.kt`),
  - a live snapshot/flow layer (`ui/HomeData.kt`, `service/StepUpdates.kt`).
- `docs/KOTLIN_CODEBASE_GUIDE.md` documents every Kotlin file's exact contract (purpose, state ownership, lifecycle rules, modification cautions). **It is large — read the sections relevant to the files below. It is the source of truth for what exists and how it behaves.**

## 2. The data you can build reports from

- **`History` table**: one row per logical day (`YYYY-MM-DD` TEXT PK, `stepsy` INT). Full history since install.
- **`Slots` table**: hourly steps per wall-clock day: `(date, slot 0..23, steps)`, `SLOT_MINUTES = 60`, `WITHOUT ROWID`. Bulk range reads exist: `Database.loadSlotsRange(minDate, maxDate)` returns `List<SlotDay>`.
- **`Adjust` table**: manual step edits `(date, minute, delta)`. The app replays adjustments into the hourly distribution (see the guide's HomeScreen / DayLineChart sections for the exact replay rules — reports must be consistent with what Home shows).
- **Day-start shifting**: the user can set a "day start" hour (presets 22/23/0..4). `Util.label(ms)` maps wall-clock ms to the logical day, so a logical day can end at 02:00. **Any range or hourly aggregation MUST respect this rule**, or report numbers will disagree with the home screen. Hour slots are wall-clock hours; their logical-day attribution depends on the shift (the home hourly chart implements this — see guide).
- **Derived data already computed and cached elsewhere (pattern to follow)**: `util/AchievementsCacheUtil.kt` computes and caches a JSON payload in SharedPreferences (schema-versioned): avg steps/day, total, goal days, top-3 days, **best week**, **best month**, **longest streak**, milestones. `util/StreakCalculator.kt` handles streaks; `util/TimedPauseManager.kt` tracks timed pauses (pauses explain zero-step gaps and matter for "logged days" style stats).

## 3. The feature

A **Reports** screen, opened from the home top-bar overflow menu as its **first item** (see HomeScreen's TopBar section in the guide). Concept: a place to view your step history in a preferable way:

- **Ranges**: week / month / year / custom (custom range via the existing `MonthCalendar` component or a new picker — your call; `MonthCalendar` already supports month navigation and selection).
- **Charts**: reuse `StepsBarChart` (daily bars with goal markers) and the hourly capabilities of `DayLineChart`/`DayBarChart` (bar + line variants, per-hour data). Add period-level aggregation charts if genuinely useful. **Hourly insight**: aggregate the whole range into 4 buckets (0–6 night, 6–12 morning, 12–18 afternoon, 18–0 evening) — e.g. "you're mostly a night walker". Respect day-start shifting when attributing slots.
- **Insight lines**: comparison vs the previous period ("+12% vs last week"), and local superlatives ("best week this year", "longest streak so far", "first 10k day in 3 months"). There is **no global/other-user data** — anything like "top 1% of users" is impossible; keep such framing local ("one of your best weeks") or drop it.
- **Empty/edge handling**: fresh installs (0 days), partial periods (current week "so far" badge), zero-step days, multi-year histories, day-start changes mid-history, DST, backup-restore.
- **Efficiency (hard requirement)**: never scan the whole DB on every screen open. Follow the established discipline: background aggregation (`Dispatchers.IO`), process-lifetime caching with explicit invalidation (data version / dirty keys), SQL-side aggregation where possible (`GROUP BY substr(date,1,7)` etc.). Study how `AchievementsCacheUtil` + `AchievementsScreen` handle recompute-on-change and cache schema versioning, and reuse that approach.
- **Reusability (hard requirement)**: the data layer (e.g. `ReportData.kt`) must be **screen-agnostic pure Kotlin (no Compose imports)** so a future Home "year recap" card (shown near New Year, summarizing the past year) can reuse the same loader, models, and summaries without a screen.

## 4. Hard constraints the implementation must respect

- **No new dependencies** — no Room, no Hilt, no chart library. Reuse in-repo chart components.
- **Match the established UI**: `StepsyTheme` color vocabulary (accent / muted / special / goal / flame / background — see `ui/theme/Theme.kt`), building blocks `Panel`, `SectionLabel`, `Eyebrow`, `ScreenHeader`, `CircleIconButton`, `PillSelector`, `StatPill`, `PrimaryButton`, `Toast` host. Radius scale is {12, 16, 24, 28}dp; big numerics use Chivo with tabular figures; labels are sentence-case; interactive targets are 48dp touch / 40dp visual.
- **Kotlin style**: minimal inline comments (the repo strips commentary; durable knowledge goes to the guide), strings in `strings.xml` following the existing naming style, graceful null/empty handling like the existing screens.
- Must not regress home-screen performance or app size.

## 5. What NOT to do

- Don't copy Taro 1:1 — it is attached as `reference/taro_report_screen.kt` purely as a structural hint (period switcher, highlights panel, stat rows, previous/next arrows, "so far" chip). Stepsy has no weight/food/sleep sections, no Voyager navigation, no story screens.
- Don't propose features that require data Stepsy doesn't store.

## 6. Your deliverables (both, in a single reply)

1. **A brief description/summary** (a few paragraphs) of how you imagine the screen: overall structure, the sections per range, the 2–3 insights/"quirks" genuinely worth building, and what you would deliberately leave out and why.
2. **A detailed implementation plan, written as a prompt addressed to the implementing agent**, containing:
   - the exact new files and their responsibilities, plus which existing files need small edits (overflow menu, `AndroidManifest.xml`, strings, the guide),
   - the data-layer design: models, loader API signatures, caching + invalidation strategy (what is computed when; how the future year-recap card would call into it),
   - per-range UI breakdown mapped to existing components, and precise specs for genuinely new components,
   - the hourly-bucket aggregation rules, including day-start shifting and Adjust replay consistency,
   - the insight/comparison rules, including how "best week this year"-style superlatives are computed efficiently over full history,
   - the string resources needed (names + English values),
   - edge cases and their handling,
   - exact code where you consider it suitable — you may write complete files if that is the cleanest way to communicate.

The implementing agent can read the repo itself; reference files and guide sections precisely instead of re-pasting their contents.

## 7. Files in this package (paths relative to the repo root)

```
docs/KOTLIN_CODEBASE_GUIDE.md                        <- the full codebase contract; source of truth
app/src/main/AndroidManifest.xml
app/src/main/res/values/strings.xml
app/src/main/java/com/nvllz/stepsy/util/Database.kt           <- SQLite schema + range loaders
app/src/main/java/com/nvllz/stepsy/util/Util.kt               <- day-start shifting, formatting, time labels
app/src/main/java/com/nvllz/stepsy/util/AppPreferences.kt      <- all persisted settings (goal, day start, theme...)
app/src/main/java/com/nvllz/stepsy/util/AchievementsCacheUtil.kt <- THE caching/aggregation pattern to follow
app/src/main/java/com/nvllz/stepsy/util/StreakCalculator.kt
app/src/main/java/com/nvllz/stepsy/util/TimedPauseManager.kt
app/src/main/java/com/nvllz/stepsy/ui/HomeData.kt             <- live snapshot/flow layer
app/src/main/java/com/nvllz/stepsy/ui/HomeScreen.kt           <- home UI incl. top-bar overflow menu
app/src/main/java/com/nvllz/stepsy/ui/DailyGoalsScreen.kt     <- closest existing relative: ranges + charts screen
app/src/main/java/com/nvllz/stepsy/ui/DailyGoalsActivity.kt   <- secondary-activity pattern
app/src/main/java/com/nvllz/stepsy/ui/AchievementsScreen.kt   <- computed-stats screen + recompute flow
app/src/main/java/com/nvllz/stepsy/ui/AchievementsData.kt
app/src/main/java/com/nvllz/stepsy/ui/MainActivity.kt
app/src/main/java/com/nvllz/stepsy/ui/theme/Theme.kt          <- StepsyTheme
app/src/main/java/com/nvllz/stepsy/ui/components/Panel.kt
app/src/main/java/com/nvllz/stepsy/ui/components/SectionLabel.kt
app/src/main/java/com/nvllz/stepsy/ui/components/Eyebrow.kt
app/src/main/java/com/nvllz/stepsy/ui/components/ScreenHeader.kt
app/src/main/java/com/nvllz/stepsy/ui/components/PillSelector.kt
app/src/main/java/com/nvllz/stepsy/ui/components/StatPill.kt
app/src/main/java/com/nvllz/stepsy/ui/components/StepsBarChart.kt
app/src/main/java/com/nvllz/stepsy/ui/components/DayLineChart.kt  <- hourly chart (bar + line variants)
app/src/main/java/com/nvllz/stepsy/ui/components/HeroBar.kt
app/src/main/java/com/nvllz/stepsy/ui/components/MonthCalendar.kt <- candidate for custom-range picking
app/src/main/java/com/nvllz/stepsy/ui/components/PrimaryButton.kt
app/src/main/java/com/nvllz/stepsy/ui/components/StepsyDialog.kt
app/src/main/java/com/nvllz/stepsy/ui/components/ChoiceDialog.kt
reference/taro_report_screen.kt                      <- Taro's report screen (hint only)
```
